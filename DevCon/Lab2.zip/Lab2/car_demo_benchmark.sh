#!/usr/bin/env bash
# Lab 2: DL Streamer car demo — benchmark pipelines with fakesink (no display).
# Linux (Ubuntu 24.04). Repeats full pipeline strings so scaling is visible in the code.

set -euo pipefail

STEP="${1:-}"

VIDEO_SRC="${VIDEO_SRC:-Videos/1900-151662242_medium.mp4}"
DETECTION_MODEL="${DETECTION_MODEL:-models/INT8/Detection/model.xml}"
CLASSIFICATION_MODEL="${CLASSIFICATION_MODEL:-models/FP16/Classification/model.xml}"
DETECTION_DEVICE="${DETECTION_DEVICE:-GPU}"
CLASSIFICATION_DEVICE="${CLASSIFICATION_DEVICE:-NPU}"
RECLASSIFY_INTERVAL="${RECLASSIFY_INTERVAL:-2}"
DECODEBIN="${GST_DECODEBIN:-decodebin3}"

usage() {
  echo "Usage: $0 STEP" >&2
  echo "STEP: single_detection | two_detection_pipelines | four_detection_pipelines | two_detection_classification_pipelines" >&2
}

if [ -z "$STEP" ]; then
  usage
  exit 1
fi

case "$STEP" in
  single_detection)
    PIPELINE="filesrc location=${VIDEO_SRC} ! ${DECODEBIN} ! gvadetect model=${DETECTION_MODEL} device=${DETECTION_DEVICE} pre-process-backend=opencv ! gvafpscounter ! videoconvert ! fakesink sync=false"
    ;;
  two_detection_pipelines)
    # Same detection branch twice in one pipeline: decode once, then tee to two parallel inference paths.
    PIPELINE="filesrc location=${VIDEO_SRC} ! ${DECODEBIN} ! tee name=t t. ! queue ! gvadetect model=${DETECTION_MODEL} device=${DETECTION_DEVICE} pre-process-backend=opencv ! gvafpscounter ! videoconvert ! fakesink sync=false t. ! queue ! gvadetect model=${DETECTION_MODEL} device=${DETECTION_DEVICE} pre-process-backend=opencv ! gvafpscounter ! videoconvert ! fakesink sync=false"
    ;;
  four_detection_pipelines)
    PIPELINE="filesrc location=${VIDEO_SRC} ! ${DECODEBIN} ! tee name=t t. ! queue ! gvadetect model=${DETECTION_MODEL} device=${DETECTION_DEVICE} pre-process-backend=opencv ! gvafpscounter ! videoconvert ! fakesink sync=false t. ! queue ! gvadetect model=${DETECTION_MODEL} device=${DETECTION_DEVICE} pre-process-backend=opencv ! gvafpscounter ! videoconvert ! fakesink sync=false t. ! queue ! gvadetect model=${DETECTION_MODEL} device=${DETECTION_DEVICE} pre-process-backend=opencv ! gvafpscounter ! videoconvert ! fakesink sync=false t. ! queue ! gvadetect model=${DETECTION_MODEL} device=${DETECTION_DEVICE} pre-process-backend=opencv ! gvafpscounter ! videoconvert ! fakesink sync=false"
    ;;
  two_detection_classification_pipelines)
    PIPELINE="filesrc location=${VIDEO_SRC} ! ${DECODEBIN} ! tee name=t t. ! queue ! gvadetect model=${DETECTION_MODEL} device=${DETECTION_DEVICE} pre-process-backend=opencv ! gvatrack ! gvaclassify model=${CLASSIFICATION_MODEL} device=${CLASSIFICATION_DEVICE} pre-process-backend=opencv reclassify-interval=${RECLASSIFY_INTERVAL} ! queue ! gvafpscounter ! videoconvert ! fakesink sync=false t. ! queue ! gvadetect model=${DETECTION_MODEL} device=${DETECTION_DEVICE} pre-process-backend=opencv ! gvatrack ! gvaclassify model=${CLASSIFICATION_MODEL} device=${CLASSIFICATION_DEVICE} pre-process-backend=opencv reclassify-interval=${RECLASSIFY_INTERVAL} ! queue ! gvafpscounter ! videoconvert ! fakesink sync=false"
    ;;
  *)
    usage
    exit 1
    ;;
esac

echo "Pipeline:"
echo "${PIPELINE}"
echo

export GST_DEBUG="${GST_DEBUG:-0}"

eval "gst-launch-1.0 ${PIPELINE}"
