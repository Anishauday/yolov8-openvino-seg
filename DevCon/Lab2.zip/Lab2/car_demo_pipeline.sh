#!/usr/bin/env bash
# Lab 2: DL Streamer car demo — run one visual pipeline by STEP.
# Linux (Ubuntu 24.04). Run from the lab directory that contains Videos/ and models/.

set -euo pipefail

STEP="${1:-}"

VIDEO_SRC="${VIDEO_SRC:-Videos/1900-151662242_medium.mp4}"
DETECTION_MODEL="${DETECTION_MODEL:-models/INT8/Detection/model.xml}"
CLASSIFICATION_MODEL="${CLASSIFICATION_MODEL:-models/FP16/Classification/model.xml}"
DETECTION_DEVICE="${DETECTION_DEVICE:-GPU}"
CLASSIFICATION_DEVICE="${CLASSIFICATION_DEVICE:-NPU}"
RECLASSIFY_INTERVAL="${RECLASSIFY_INTERVAL:-2}"
DECODEBIN="${GST_DECODEBIN:-decodebin3}"

usage() {
  echo "Usage: $0 STEP" >&2
  echo "STEP: display_video | car_detection | car_detection_classification" >&2
}

if [ -z "$STEP" ]; then
  usage
  exit 1
fi

case "$STEP" in
  display_video)
    PIPELINE="filesrc location=${VIDEO_SRC} ! ${DECODEBIN} ! videoconvert ! autovideosink sync=true"
    ;;
  car_detection)
    PIPELINE="filesrc location=${VIDEO_SRC} ! ${DECODEBIN} ! gvadetect model=${DETECTION_MODEL} device=${DETECTION_DEVICE} pre-process-backend=opencv ! gvawatermark ! gvafpscounter ! videoconvert ! autovideosink sync=true"
    ;;
  car_detection_classification)
    PIPELINE="filesrc location=${VIDEO_SRC} ! ${DECODEBIN} ! gvadetect model=${DETECTION_MODEL} device=${DETECTION_DEVICE} pre-process-backend=opencv ! gvatrack ! gvaclassify model=${CLASSIFICATION_MODEL} device=${CLASSIFICATION_DEVICE} pre-process-backend=opencv reclassify-interval=${RECLASSIFY_INTERVAL} ! queue ! gvawatermark ! gvafpscounter ! fpsdisplaysink video-sink=autovideosink text-overlay=true sync=true"
    ;;
  *)
    usage
    exit 1
    ;;
esac

echo "Pipeline:"
echo "${PIPELINE}"
echo

export GST_DEBUG="${GST_DEBUG:-0}"
export GST_DEBUG_NO_COLOR="${GST_DEBUG_NO_COLOR:-1}"

set +e
eval "gst-launch-1.0 ${PIPELINE}"
# Closing the video window often yields a nonzero exit; treat as OK for lab display runs.
exit 0
